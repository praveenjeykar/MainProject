package com.cg.emp.dao;

import com.cg.emp.bean.Employee;
import com.cg.emp.exception.EmployeeException;
import java.util.List;


public interface EmployeeDao {
  List<Employee> getAllEmployees() throws EmployeeException;
  List<Employee> deleteEmployee(int id) throws EmployeeException;
  List<Employee> addEmployee(Employee emp) throws EmployeeException;
  Employee getEmployeeById(int id) throws EmployeeException;
  List<Employee> updateEmployee(Employee emp) throws EmployeeException;
}
