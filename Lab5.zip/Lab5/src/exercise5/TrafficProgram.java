package exercise5;
import java.util.*;
public class TrafficProgram {
	public static void main(String args[])
	{
		trafficLight();
	}
     public static void trafficLight() {
    	 String m;
    	 Scanner sc= new Scanner(System.in);
    	 m=sc.next();
    	 sc.close();
    	 switch(m) {
    	 case "red" : System.out.println("stop");
    	               break;
    	 case "yellow" : System.out.println("ready");
                       break;
    	 case "green" : System.out.println("go");
                       break;
    	 default: System.out.println("InvalidOption");
    	 }
    	 
    	 
     }
}
