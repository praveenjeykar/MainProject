package com.dao.cc;

import java.util.ArrayList;

import com.bean.cc.Order;
import com.sr.cc.Servicecc;





public class DataBaselayer {
  public void Store(Order obj, int percentageOrder)
  {
	  ArrayList<String> list = new ArrayList<String>();
	  list.add("iD: "+obj.getId());
	  list.add("price: "+obj.getPrice());
	  list.add("quantity: "+obj.getQuantity());
	  list.add("amount: "+obj.getAmount());
	  list.add("charges: "+obj.getCharges());
    
	  Servicecc mo= new Servicecc();
	  mo.calculate01(obj);
  }  
}

	 
	  


