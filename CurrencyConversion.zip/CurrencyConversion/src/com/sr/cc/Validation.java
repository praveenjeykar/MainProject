package com.sr.cc;

public class Validation {
	public boolean validateprice(double  price)//exception when price is less then 0
    {
           try {
               if(price > 0)
                   return true;
           else
               throw new Exception("it  is not valid");
       }catch(Exception e) {
           System.out.println(e);
       }
       return false;
      
   }
	public boolean validatequantity(int  quantity)//exception when quantity is less then 0
    {
           try {
               if(quantity > 0)
                return true;
        else
            throw new Exception("it  is not valid");
    }catch(Exception e) {
        System.out.println(e);
    }
    return false;
   
}
	public boolean validateamount(double  amount) //exception when amount is less then 0
    {
           try {
               if(amount > 0)
                return true;
        else
            throw new Exception("it  is not valid");
    }catch(Exception e) {
        System.out.println(e);
    }
    return false;
   
}