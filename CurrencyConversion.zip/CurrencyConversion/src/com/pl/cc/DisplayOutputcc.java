package com.pl.cc;

import java.util.ArrayList;

public class DisplayOutputcc {
	
	public void showOutputcc(ArrayList<String> a) {
		 
		        System.out.println(a);
	}
}