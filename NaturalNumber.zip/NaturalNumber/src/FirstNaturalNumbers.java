
public class FirstNaturalNumbers {
	int a,b,c;
	
	a=((n/x)*(2*x+(n/(x-1)*x))/2;
	b=((n/y)*(2*y+(n/(y-1)*y))/2;
	c=a=((n/x)*(2*x+(n/(x-1)*x))/2;
	
	
	public static void main(String args[]) { 
		System.out.prinln("enter the number");
		int n;
		Scanner sc = new Scanner(System.in);
		
		
		
	}
	

}
