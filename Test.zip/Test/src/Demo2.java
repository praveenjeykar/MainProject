
public class Demo2 {
	public static void main(String ar[]) {
		try {
		//JDBC code
		}
	}
}