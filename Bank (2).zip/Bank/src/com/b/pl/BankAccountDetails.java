package com.b.pl;

import java.util.Scanner;

import com.b.ser.ServiceLayer;

public class BankAccountDetails {
     public static void main(String args[]) {
    	 System.out.print("Welcome to Bank Account Details \n");
    	 System.out.print("------------------------------------------\n");
    	 System.out.print("1.Create Balance\n");
    	 System.out.print("2.Show Balance\n");
    	 System.out.print("3.Deposit\n");
    	 System.out.print("4.Withdraw\n");
    	 System.out.print("5.Fund Transfer\n");
    	 System.out.print("6.Print Transcations\n");
    	 int n;
    	 Scanner sc= new Scanner(System.in);
    	 n=sc.nextInt();
    	 switch(n) {
    	 case 1: CreateAccount cb = new CreateAccount();
    		     cb.createBalance();
    		     break;
    		     
    	 case 2: ServiceLayer de = new ServiceLayer();
    	         de.deposit();
    	         break;
  
    	 case 3: ServiceLayer fd = new ServiceLayer();
    	         fd.fundTransfer();
                 break;
 
    	 case 4: ServiceLayer pt= new  ServiceLayer();
    	         pt.printTranscations();
    	         break;
    	         
    	 case 5: ServiceLayer sb = new ServiceLayer();
    	         sb.showBalance();
    	         break;
    	         
    	 case 6: ServiceLayer wi = new ServiceLayer();
    	         wi.withdraw();
    	         break;
    	         
    	 case 7: System.exit(0);    
    	 
    	 default: System.out.println("Invalid Option");
    	 }
    	sc.close(); 
     }
}
