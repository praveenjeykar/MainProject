package com.b.pl;

import java.util.Scanner;

import com.b.bean.BankDetails;

public class CreateAccount {
        public void  createBalance() {
        
        	BankDetails bd= new BankDetails();
        	
        	 int Id;
        	 String Name;
             String AccountNumber;
             String PhoneNumber;
             int Balance;
             int Pin;
           
            Scanner scx= new Scanner(System.in);
            
           System.out.println("Enter the Accountant Id");
           Id=scx.nextInt();
           bd.setId(Id);
           
           System.out.println("Enter the Accountant Name");
           Name=scx.next();
           bd.setName(Name);
           
           System.out.println("Enter the Accountant Number");
           AccountNumber=scx.next();
           bd.setAccountNumber(AccountNumber);
         
           
//           public boolean validateMobileNum(String mobileNum) {
//        	    // TODO Auto-generated method stub
//        	    try{
//        	        if(mobileNum.matches("(\\+91(-)?|91(-)?|0(-)?)?((9)|(8)|(7))[0-9]{9}"))
//        	            return true;
//        	        else
//        	            throw new Exception("Number is not valid");
//        	    }catch(Exception e) {
//        	        System.out.println(e);
//        	        
//        	    }
//        	    return false;
//        	}
           
           
           int x=1;
           while(x==1) {
        	   System.out.println("Enter the Accountant PhoneNumber ");
               PhoneNumber=scx.next();
          
           if(PhoneNumber.matches("(\\+91(-)?|91(-)?|0(-)?)?((9)|(8)|(7))[0-9]{9}"))
           {
        	   bd.setPhoneNumber(PhoneNumber);
        	   x++;
           }
           else {
               System.out.println("Invalid Phone Number");
               x=1;  
           	}
           
           }
           
          
           System.out.println("Enter the Accountant Balance");
           Balance=scx.nextInt();
           bd.setBalance(Balance); 
         
           System.out.println("Enter 4-digit pin:");
           Pin=scx.nextInt();
           bd.setPin(Pin);
           
          int i=1;
           while(i==1) {
           System.out.println("Re-enter the pin:");       
           int pin1 = scx.nextInt();
           if(Pin==pin1) {
           bd.setPin(Pin);
           i++;
           }
           else
           {
               System.out.println("Incorrect Pin");
               i=1;
           }
           }
           
           System.out.println("Id:"+bd.getId()+"\n"+
        		              "Name: "+bd.getName()+"\n"+
                              "AccountNumber:"+bd.getAccountNumber()+"\n"+
                              "PhoneNumber:"+bd.getPhoneNumber()+"\n"+
                              "Balance:"+bd.getBalance()+"\n"+
                              "Pin:"+bd.getPin());
           scx.close();
        }
       
        
}
        		   
        		             
                          
           
        	
        	
        