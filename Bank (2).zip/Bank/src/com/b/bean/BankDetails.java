package com.b.bean;

import java.util.ArrayList;
import java.util.List;

public class BankDetails {
	
	private int Id;
	private String Name;
    private String AccountNumber;
    private String PhoneNumber;
    private int Balance;
    private int Pin;
    
    private List<String> trans = new ArrayList<String>();
    
	public BankDetails(int Id, String Name,String AccountNumber,String PhoneNumber,int Balance, int Pin) {
		this.Id=Id;
		this.Name=Name;
		this.AccountNumber=AccountNumber;
		this.PhoneNumber=PhoneNumber;
		this.Balance=Balance;
		this.Pin=Pin;
				
	}
    
    public void bank() {
    	
    }
    
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getAccountNumber() {
		return AccountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		AccountNumber = accountNumber;
	}
	public String getPhoneNumber() {
		return PhoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		PhoneNumber = phoneNumber;
	}
	public int getBalance() {
		return Balance;
	}
	public void setBalance(int balance) {
		Balance = balance;
	}
	public int getPin() {
		return Pin;
	}
	public void setPin(int pin) {
		Pin = pin;
	}
	@Override
	public String toString() {
		return "BankDetails [Id=" + Id + ", Name=" + Name + ", AccountNumber=" + AccountNumber + ", PhoneNumber="
				+ PhoneNumber + ", Balance=" + Balance + ", Pin=" + Pin + "]";
	}
	
}
	
    
	  