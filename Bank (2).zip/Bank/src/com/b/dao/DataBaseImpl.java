package com.b.dao;

public class DataBaseImpl {

}
