package threads;

public class WaitNotifyDemo {

}
