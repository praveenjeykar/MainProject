package threads;
class SampleThread extends Thread{
	public void run() {
		Thread.sleep(milliseconds);
		System.out.println("Sample Thread RunMethod");
	}
}
class SampleThreadImp implements Runnable{
	public void run() {
		  int i,count=0;
		  for(i=0;i<=10;i++) {
			  count++;
			  System.out.println("RunMethodMoni "+count);
		  }
		 
	}
	
}
public class ThreadDemo {
	public static void main(String args[]) {
		SampleThread st= new SampleThread();
		st.start();
		SampleThreadImp sti= new SampleThreadImp();
		SampleThreadImp sto= new SampleThreadImp();
		Thread t=new Thread(sti);
		Thread m=new Thread(sto);
		t.start();
		m.start();
		
	}

}
