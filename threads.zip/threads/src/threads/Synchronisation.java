package threads;

public class Synchronisation {
	synchronized void dispaly() {
		System.out.println(Thread.currentThread().getName());
		 for(int i=0;i<5;i++) {
			 System.out.println(i);
			 try {
				 Thread.sleep(6000);
	       }catch(InterruptedException e) {
	    	   System.out.println(e);
	       }
		 }
	}

}
public class SynchronizedMethodDemo implements Runnable{
	Synchronisation mObj;
	SynchronizedMethodDemo(Synchronisation m,String name){
		mObj=m;
		Thread t=new Thread(this,name);
		t.start();
	}
	public void run() {
		mObj.display();
	}
	public static void main(String args[]) {
		
	}
}