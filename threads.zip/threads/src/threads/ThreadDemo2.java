package threads;

public class ThreadDemo2 {
	public class ThreadDemo implements Runnable{
		DemoThread(){
			Thread t=new Thread(this);
			t.start();
		}
		public void run() {
			System.out.println("Hello");
		}
		public static void main(String args[]) {
			DemoThread st= new DemoThread();
			st.start();
	}
	}
}
