package com.mo;

import java.util.Arrays;
import java.util.*;

public class getSorted {
	public static void main(String args[]) 
	{
		getsorted();
	}
	public static void getsorted() { 
		int n=10,i,temp;
		Scanner sc= new Scanner(System.in);
		n=sc.nextInt();
		int[] a = new int[n];
		for(i=0;i<n;i++)
		{
			a[i]=sc.nextInt();
		}
		for(i=0;i<n/2;i++) 
		{
			temp=a[i];
			a[i]=a[n-i-1];
			a[n-i-1]=temp;
		}
		sc.close();
		Arrays.sort(a);
		for(int s:a)
		{
			System.out.println(s);
		}
	}

}
