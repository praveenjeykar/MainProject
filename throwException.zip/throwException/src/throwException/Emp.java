package throwException;

import java.util.TreeSet;
import java.util.*;

public class Emp implements Comparable<Emp>{
	
		int Empid;
		String Name;
		public Emp(int Empid, String Name){
			super();
			this.Empid= Empid;
			this.Name= Name;
		}
		public String toString() {
			return Empid + "" + Name; 
			
		}
		
		public static void main(String[] args) {
		Emp emp1 = new Emp(1 ," moni ");
		Emp emp2 = new Emp(2 ," Kiki ");
		
		
		TreeSet<Emp> ts= new TreeSet<Emp>();
		ts.add(emp1);
		ts.add(emp2);
		System.out.println(ts);
	}

		@Override
		public int compareTo(Emp obj) {
			if(this.Empid == obj.Empid)
			return 0;
			else
				return this.Empid>obj.Empid?1:-1;
		}

}
