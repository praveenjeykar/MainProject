
public class Validationss {
	
	    public boolean validateName(String empName) {
	        try {
	            if(empName.matches("([A-Z][a-z]+)*"))
	                    return true;
	            else
	                throw new Exception("Name is not valid");
	        }catch(Exception e) {
	            System.out.println(e);
	        }
	        return false;
	    }
}


public boolean validateMobileNum(String mobileNum) {
    // TODO Auto-generated method stub
    try{
        if(mobileNum.matches("(\\+91(-)?|91(-)?|0(-)?)?((9)|(8)|(7))[0-9]{9}"))
            return true;
        else
            throw new Exception("Number is not valid");
    }catch(Exception e) {
        System.out.println(e);
        
    }
    return false;
}



public boolean validateMail(String empMail) {
    // TODO Auto-generated method stub
    try{
        if(empMail.matches("^[a-zA-Z0-9_+&*-]+(?:\\."+ "[a-zA-Z0-9_+&*-]+)*@" + "(?:[a-zA-Z0-9-]+\\.)+[a-z" + "A-Z]{2,7}$"))
            return true;
        else
            throw new Exception("MailId is not valid");
    }catch(Exception e) {
        System.out.println(e);
        
    }
    return false;
}



}