package com.cg.eis.exception;
import java.util.*;
public class SortingCollection {
	public static void main (String args[]) {
		int a[]= {14,8,90,23,7};
		Arrays.sort(a);
		for(int i:a)
			System.out.println(i);
				LinkedList<String> lobj = new LinkedList<String>();
				lobj.add("jake");
				lobj.add("kake");
				lobj.add("lill");
				System.out.println(lobj);
				System.out.println("*********");
				Collections.sort(lobj);
				System.out.println(lobj);
				
	}

}
