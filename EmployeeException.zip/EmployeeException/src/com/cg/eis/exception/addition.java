package com.cg.eis.exception;
import java.util.Scanner;


public class addition {
	
public static void main(String args[]) {
 System.out.println("Enter the two numbers");
 int a,b,c;
 Scanner sc= new Scanner(System.in);
 a=sc.nextInt();
 b=sc.nextInt();
 c=a+b;
 System.out.println("addtion of two numbers is" +c);

}
}

