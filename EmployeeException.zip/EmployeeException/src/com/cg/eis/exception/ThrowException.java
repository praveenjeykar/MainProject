package com.cg.eis.exception;
import java.util.Scanner;

 class ThrowException extends RuntimeException{
	public String toString() {
		return "Exception found" ;
	}
	public static void main(String args[]) {
		Scanner sc = new Scanner (System.in);
		System.out.println("Salary of an employee");
		int Salary;
		Salary = sc.nextInt();
		sc.close();
		try {
			if (Salary<3000) 
				throw new ThrowException();
			else
				System.out.println("no output found");
			}
		catch(Exception e) {
			System.out.println(e);
		}
		
				
				
	} 
	
	
	

}
