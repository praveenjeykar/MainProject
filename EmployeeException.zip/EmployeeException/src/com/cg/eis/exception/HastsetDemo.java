package com.cg.eis.exception;

public class HastsetDemo {
	public static void main(String args[]) {
	HastSet hs= new HastSet();
          Integer iobj=5;
	      hs.add(1);
	      hs.add(1);
	      hs.add(1.2);
	      hs.add("Hello");
	      hs.add(9.7);
	      System.out.println(hs);
	      Iterator i=hs.iterator();
	      while(i.hasNext) {
	    	  System.out.println(i.Next());
	      }
}
