package com.cg.eis.exception;
import java.util.*;
public class HashSetDemo {
		public static void main(String args[]) {
		HashSet hs= new HashSet();
		      hs.add(1);
		      hs.add(1.2);
		      hs.add("Hello");
		      System.out.println(hs);
		     
		      Iterator i=hs.iterator();
		      while(i.hasNext()) {
		    	  System.out.println(i.next());
		      }
		      LinkedHashSet lhs = new LinkedHashSet(); 
		      lhs.add(2);
		      lhs.add(1);
		      lhs.add("hi");
		      System.out.println(lhs);
		      
		}

}
