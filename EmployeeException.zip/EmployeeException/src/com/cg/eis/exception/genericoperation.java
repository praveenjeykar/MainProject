package com.cg.eis.exception;
import java.util.Scanner;

public class genericoperation {
 public static < E > void addition(E a,E b) { 
	 System.out.println(a+b);
		
	public static void main(String args[]) {
	 System.out.println("Enter the two numbers");
	 int a,b,c;
	 Scanner sc= new Scanner(System.in);
	 a=sc.nextInt();
	 b=sc.nextInt();
	 addition(a,b);
	 }
	}

}
