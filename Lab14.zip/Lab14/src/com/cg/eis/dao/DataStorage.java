package com.cg.eis.dao;

import java.io.IOException;
import java.util.ArrayList;
import com.cg.eis.bean.Employee;
import com.cg.eis.pl.DisplayOutput;
import com.cg.eis.service.Services;	 

public class DataStorage {	 

	    public void storeData(Employee emp, Services serve) throws IOException {
	        ArrayList<String> arrayList = new ArrayList<String>();
	        arrayList.add("Employee ID: " + emp.getEmpId());
	        arrayList.add("Name: "+ emp.getName());
	        arrayList.add("Salary: Rs. " + emp.getSalary());
	        arrayList.add("Designation: " + emp.getDesignation());
	        arrayList.add("Insurance Sceme: " + emp.getInsuranceScheme());
	        arrayList.add("Services provided: " + serve.getService());
	        
	        
	        DisplayOutput displayOutput = new DisplayOutput();
	        displayOutput.showOutput(arrayList);
	        }
	}


