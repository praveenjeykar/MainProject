package com.la.bean;

public class Students {
	 private int StudentId;
	 private String name;
     private String classname;
	 private int marks;
	 private int grade;
	 private int age;
	 String performance;
	 
	
	public String getPerformance() {
		return performance;
	}
	public void setPerformance(String performance) {
		this.performance = performance;
	}
	@Override
	public String toString() {
		return "Students [StudentId=" + StudentId + ", name=" + name + ", classname=" + classname + ", marks=" + marks
				+ ", grade=" + grade + ",age=" + age + "]";
	}
	public int getStudentId() {
		return StudentId;
	}
	public void setStudentId(int studentId) {
		StudentId = studentId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getClassname() {
		return classname;
	}
	public void setClassname(String classname) {
		this.classname = classname;
	}
	public int getMarks() {
		return marks;
	}
	public void setMarks(int marks) {
		this.marks = marks;
	}
	public int getGrade() {
		return grade;
	}
	public void setGrade(int grade) {
		this.grade = grade;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	
}
	
