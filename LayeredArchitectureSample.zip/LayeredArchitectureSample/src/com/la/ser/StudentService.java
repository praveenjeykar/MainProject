package com.la.ser;

import com.cg.eis.service.Services;

public class StudentService {
  public void Studentttt(Students stu) {
	  Services s = new Services();
  
	  if(stu.getPerformance().equals(" scheme A")) {
		  s.setService("FIRST PRIZE");
	  }
	  if(stu.getPerformance().equals(" scheme B")) {
		  s.setService("THIRD PRIZE");
	  }
	  if(stu.getPerformance().equals(" scheme C")) {
		  s.setService("SECOND PRIZE");
	  }
  }
}
