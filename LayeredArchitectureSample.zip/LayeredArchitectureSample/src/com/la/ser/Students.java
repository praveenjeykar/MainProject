package com.la.ser;

public interface Students {

}
