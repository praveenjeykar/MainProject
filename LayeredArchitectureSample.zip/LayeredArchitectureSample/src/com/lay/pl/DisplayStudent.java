package com.lay.pl;

import java.util.ArrayList;

public class DisplayStudent {
	
	public void outputDispaly(ArrayList<String> al) {
		
		for(String str: al ) {
			System.out.println(str);
		}
	}

}
