package com.lay.pl;

import java.util.ArrayList;
import java.util.Scanner;

public class MainClass {
	public static void main(String args[]) {
		System.out.println("Performance Of The Student");
		System.out.println();
		System.out.println("enter the details of student");
		System.out.println("display the details of student");
		System.out.println("exit");
		System.out.println("enter your choice");
		int n;
		Scanner sc=new Scanner(System.in);
		n=sc.nextInt();
		ArrayList<String> a = new ArrayList<String>();
		a=null;
		switch(n) {
		case 1: StudentDetails sd= new StudentDetails();
		        sd.DetailsInput();
		        break;
		case 2: DisplayStudent ds= new DisplayStudent();
		        ds.outputDispaly(a);
		        break;
		case 3:System.exit(0);
		       break;
		default: System.out.println("enter the correct choice");       
		}
		sc.close();
		
	}

}
