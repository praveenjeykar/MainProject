package com.lay.pl;
	import java.util.Scanner;

import com.la.bean.Students;
import com.la.ser.StudentService;

	public class StudentDetails {
	  public void DetailsInput() {
		  int id;
		  String Name;
		  int Age;
		  int Grade;
		  String Classname;
		  
		 Students s = new Students();
		  
		  Scanner sc=new Scanner(System.in);
		  System.out.println("enter the id of the student");
		  id=sc.nextInt();
		  s.setStudentId(id);
		  
		  
		  System.out.println("enter the name of the student");
		  Name=sc.nextLine();
		  s.setName(Name);
		  
		  System.out.println("enter the age of the student");
		  Age=sc.nextInt();
		  s.setAge(Age);
		  
		  System.out.println("enter the grade of the student");
		  Grade=sc.nextInt();
		  s.setGrade(Grade);
		  
		  System.out.println("enter the classname of the student");
		  Classname=sc.nextLine();
		  s.setClassname(Classname);
		 
		   sc.close();
		   if(Age>=15 && Grade =='a' && Classname.equals("tenth") ) {
			   s.setPerformance(" Excellent");
		   }
		   else if(Age==10 &&  Grade =='c' && Classname.equals("eight")) {
			   s.setPerformance("good"); 
		   }
		   else if(Age<=5 && Grade=='b' && Classname.equals("first")) {
			   s.setPerformance("verygood");
		   }
		   else {
			   s.setPerformance("the performance is bad");  
		   }
			  StudentService ss= new StudentService();
                ss.Studentttt(s);
		 }
	}
