

public class LamdaExpression3 {
	public static void main(String args[]) {
		Sum1 s=(num1,num2)->{
			int min=num1>num2?num2:num1;
			return min;
		  };
		int x=s.calcSum1(10,12);
		System.out.println(x);
	}
}

