@ FunctionalInterface
interface Bounceable{                                               
	public void bounce();
}
class Ball implements Bounceable{
	public void bounce() {
		System.out.println("BallBouncing");
	}
}
public class AnonymusInner {
	public static void main(String args[]) {
		Ball b=new Ball();
		b.bounce();
		Bounceable b1= new Bounceable() {
			public void bounce() {
				System.out.println("Anonymus bouncing");
			}
		};
	}

}
