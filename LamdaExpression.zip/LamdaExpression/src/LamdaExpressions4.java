@FunctionalInterface
interface Sum4{
	int calcSum4(int num1,int num2);
public class LamdaExpressions4 {
 public static void main(String args[]) {
	 sum4 s= ()->"Hello World!";
 }
}
}
