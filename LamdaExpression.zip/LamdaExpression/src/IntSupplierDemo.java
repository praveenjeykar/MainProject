import java.util.function.*;
public class IntSupplierDemo {
  public static void main(String args[]) {
	  
	  IntSupplier supplier1 = () ->Integer.MAX_VALUE;
	  System.out.println("Max value"+supplier1.getAsInt());
	  IntSupplier supplier2 = () ->Integer.MIN_VALUE;
	  System.out.println("Min value"+supplier2.getAsInt());
	  int a=5;
	  int b=10;
	  IntSupplier supplier3=()->a*b;
	  System.out.println(supplier3.getAsInt());
	  IntSupplier supplier4=()->Integer.compare(a,b);
	  System.out.println(supplier3.getAsInt());
	     
  }
}
