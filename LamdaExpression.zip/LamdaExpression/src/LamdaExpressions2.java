@FunctionalInterface
interface Sum1{
	int calcSum1(int num1,int num2);
}
public class LamdaExpressions2 {
	public static void main(String args[]) {
		Sum1 s=(num1,num2)->num1+num2;
		int x=s.calcSum1(10,12);
		System.out.println(x);
	}
}