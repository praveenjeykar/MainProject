enum Colour{
	green,red,yellow,blue;
}
interface StateChangeListner{
	public void onStateChange() {
	System.out.println("enter the Colour");
	
}
class Owner implements StateChangeListner{
	void add() {
	System.out.println("colour");
}
	class sampleState(){
		public void ChangeColour() {
			
		}
		
	}
	class SampleState{
	public void ChangeColour() {
		System.out.println("ChangeColour");
	}
	}	
	class TestSample{
	public void DisplayColour() {
		System.out.println("DisplayColour");
	}	
	}
public class AnanymousDemo2 {
   public static void main(String args[]) {
	SampleState obj1= new SampleState();
	TestSample obj2= new TestSample();
	obj1.ChangeColour();
	obj2.DisplayColour();
}
}

