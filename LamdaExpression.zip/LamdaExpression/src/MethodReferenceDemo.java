import java.util.function.Function;

public class MethodReferenceDemo {
	 public static void main(String args[]) {
		 System.out.println(String.valueOf(65));
		 Function<Integer, String> func1=
				 x->String.valueOf(x);
		System.out.println("Function"+func1.apply(10));
		Function<Integer,String> func2= String::Valueof;
		System.out.println(func2.apply(10));
		BiFunction<Integer,Integer,Integer> func4=Integer::sum;
		System.out.println(func4.apply(2,3));
		Messageable m=Message::new;
		m.getMessage("Hi");
		Message mobj=new Message();
		Function<String, Integer> c = mobj::calcLength;
		System.out.println(c.apply("hello"));
		BiFunction<Integer,Integer,Integer>fun3=(x,y)->Integer.sum(x,y);
		System.out.println(fun3.apply(2,3));
     	 }

}
