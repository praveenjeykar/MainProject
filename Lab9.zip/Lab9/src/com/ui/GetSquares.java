package com.ui;
	import java.util.*;
	public class GetSquares {
	    public static void main(String args[])
	    {
	        GetTheSquare();
	    }


	    static void GetTheSquare() {
	        Map<Integer,Integer> map = new HashMap<Integer,Integer>();
	        int[] a = new int[5];
	        Scanner sc = new Scanner(System.in);
	        for(int i=0;i<5;i++)
	        {
	            a[i]=sc.nextInt();
	        }
	        for(int i=0;i<5;i++)
	        {
	            map.put(a[i], a[i]*a[i]);
	        }
	        System.out.println(map);
	        sc.close();
	    }


	}


