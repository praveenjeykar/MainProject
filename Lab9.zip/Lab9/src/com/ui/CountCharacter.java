package com.ui;

import java.util.HashMap;
import java.util.Scanner;

public class CountCharacter {
		    static void countCharacter()
	    {
	        String str;
	        Scanner sc=new Scanner(System.in);
	        str=sc.next();
	        HashMap<String, Integer> count = new HashMap<String, Integer>();
	        for(char ch : str.toCharArray())
	        {
	            String s = ch+"";
	            if(!count.containsKey(s)) {
	                count.put(s,1);
	            }
	            else
	                count.put(s, count.get(s)+1);
	        }
	        System.out.println(count);
	        sc.close();
	    }
	    public static void main(String args[])
	    {
	        countCharacter();
	    }

	 

	}

