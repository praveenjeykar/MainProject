import java.io.*;
import java.nio.file.Files;
public class Exercise4 {
	public static void main(String args[]) throws IOException { 
		File file = new File("C:\\Users\\mbeera\\Desktop\\MoniMonica.txt");
		String fileType="undefined";
		if((file.exists())) {
			System.out.println("file found");
		}
			if((file.canWrite())) {
				System.out.println("file writeable");
			}
				if((file.canRead())) {
					System.out.println("file readable");
			
				 fileType= Files.probeContentType(file.toPath());
				 System.out.println(file.length());
				 System.out.println(file.length());
				 System.out.println(fileType);
				}
				 else
					 System.out.println("file not found");
				 
	}
}
