package regex;

public class MobileValidationNumber {
	public static void main(String args[]){
		String mobilenumber="8919237529";

		if(mobilenumber.matches("(\\+91(-)?|0(-)?|91(-)?)?((9)|(8)|(7))[0-9]{9}"))
				System.out.println("valid mobile number");
		else
			System.out.println("invalid mobile number");
	}

}
