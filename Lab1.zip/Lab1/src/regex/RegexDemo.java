package regex;

import java.util.regex.*;

public class RegexDemo {
	public static void main(String args[]) {
	String text ="Welcome to regex";   //input string
	String regex= ".*regex.*";        
	boolean matches = Pattern.matches(regex, text);
	System.out.println("matches="+matches);
	}
}
