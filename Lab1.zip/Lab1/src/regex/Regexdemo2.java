package regex;

import java.util.regex.*;

public class Regexdemo2 {
	public static void main(String args[]) {
		String text ="My name is Monica You";   //input string
		String regex= "You";
		 Pattern pattern = Pattern.compile(regex);
		 Matcher matcher = pattern.matcher(text);
		 int count=0;
		 while(matcher.find()) {
			 count++;
			 System.out.println("found: "+count +":"+matcher.start()+"-"+matcher.end());
		 }
	}
}
