package regex;
import java.util.*;
public class NameValidationWithSpace {
	public static void main(String args[]) {
		String name="Monica HoNey";  //INPUT STING
		
		if(name.matches("[A-Z]+([a-zA-Z]+)*")) 
			System.out.println("vvvvalid name");
		else if(name.matches("[A-Z]+([ ]|[a-zA-Z]+)*")) 
			System.out.println("valid name");
		else
			System.out.println("invalid name");
	}

}
