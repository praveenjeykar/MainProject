package regex;

public class ObjectWrittenDemo {
	public static void main(String args[])throws Exception {
		
		
	}
	
	

}
