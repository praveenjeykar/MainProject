
public class SampleTest {
	String s="Hello";
	void getData() {
		s="hi";
	}
	void putData() {
		System.out.println("putDataMethod"+s);
	
	}
      static void printData()
      {
    	  System.out.println(                      );
      }
}
