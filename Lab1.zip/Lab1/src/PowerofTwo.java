import java.util.Scanner;

public class PowerofTwo {
   public static void main(String args[]) { 
	  poweroftwo();
   }
   public  static void poweroftwo() {
	   int n;
	   System.out.println("enter the number");
	   boolean flag =true;
	   Scanner sc= new Scanner(System.in);
	   n=sc.nextInt();
	   sc.close();
	   while(n>=1) {
		   if(n%2==0) { 
			   flag=false;
		   }
		   n=n/2;
	   }
		   if(flag == true) {
			   System.out.println("This is power of 2");
		   }
		   else
			   System.out.println("This is not power of 2");
	   }
	 
	 
}

