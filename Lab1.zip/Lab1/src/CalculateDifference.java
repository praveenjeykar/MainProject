import java.util.Scanner;

public class CalculateDifference {
	public static void main(String args[]) { 
		  caldiff();
	   }
	   public static void caldiff() {
		   int n,sum1=0,sum2=0,diff,i;
		   System.out.println("enter the number");
		   Scanner sc= new Scanner(System.in);
		   n=sc.nextInt();
		   sc.close();
		   for(i=1;i<=n;i++)
		   {
			   sum1= sum1+(i*i);
			   sum2= sum2+(i);
		   }
		   diff=(sum1-(sum2*sum2));
		   System.out.println("sum diff" +diff);
}
}