
import java.util.Scanner;

public class CheckNumber {
	public static void main(String args[]){
		  CheckNum();
	}
		public static void CheckNum() {
			int n,temp,flag=0;
			Scanner sc = new Scanner(System.in);
			n=sc.nextInt();
			sc.close();
			while(n!=0) {
				temp=n%10;
				n=n/10;
				if(temp<(n%10)) {
					flag = 1;
					break;
				}
			}
		if(flag == 0)
			System.out.println("Increasing Number");
		else
			System.out.println(" Not in Increasing Number");	
		}

}
