package com.ser;

	import java.util.ArrayList;

	 

	import com.bean.StudentMarks;
	import com.dao.*;
import com.pl.Output;

	
	public class Service {	 

	    public void calculate(StudentMarks sm) {
	        int percent;
	        percent=(sm.getMaths()+sm.getChem()+sm.getPhysics())/3;
	        DataBase db = new DataBase();
	        db.store(sm,percent);
	    }
	    public void transfer(ArrayList<String> a)
	    {
	        Output op= new Output();
	        op.outputDisplay(a);
	    }

	 

	}

