package com.bean;

public class StudentMarks {
   
    int Id;
    String name;
    int maths;
    int physics;
    int chem;
    public int getId() {
        return Id;
    }
    public void setId(int id) {
        Id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public int getMaths() {
        return maths;
    }
    public void setMaths(int maths) {
        this.maths = maths;
    }
    public int getPhysics() {
        return physics;
    }
    public void setPhysics(int physics) {
        this.physics = physics;
    }
    public int getChem() {
        return chem;
    }
    public void setChem(int chem) {
        this.chem = chem;
    }
}
