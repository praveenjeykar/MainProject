package com.dao;
import java.util.ArrayList;



import com.bean.*;
import com.ser.Service;
public class DataBase {
	

	
	    public void store(StudentMarks sm,int percent)
	    {
	        ArrayList<String> list = new ArrayList<String>();
	        list.add("Student ID: "+sm.getId());
	        list.add("Student Name: "+sm.getName());
	        list.add("Math marks: "+sm.getMaths());
	        list.add("Physics marks: "+sm.getPhysics());
	        list.add("Chemistry: "+sm.getChem());
	        list.add("Student Percentage: "+percent);
	    
	        Service objj = new Service();
	        objj.transfer(list);
	    }

	 

	}

