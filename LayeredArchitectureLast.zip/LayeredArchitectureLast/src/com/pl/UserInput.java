package com.pl;

import java.util.Scanner;

import com.bean.StudentMarks;
import com.dao.DataBase;
import com.ser.Service;


	public class UserInput {


	    public void userInput() {
	        Service ser = new Service();
	        
	        int Id;
	        String name;
	        int maths;
	        int physics;
	        int chem;
	        Scanner sc = new Scanner(System.in);
	        
	        StudentMarks sm = new StudentMarks();
	        
	        System.out.print("Enter the Student ID");
	        Id=sc.nextInt();
	        sm.setId(Id);
	        
	        System.out.print("Enter the Student Name");
	        name=sc.next();
	        sm.setName(name);
	        
	        System.out.print("Enter the Maths Marks");
	        maths=sc.nextInt();
	        sm.setMaths(maths);
	        
	        System.out.print("Enter the Physics Marks");
	        physics=sc.nextInt();
	        sm.setPhysics(physics);
	        
	        System.out.print("Enter the Chemistry Marks");
	        chem=sc.nextInt();
	        sm.setChem(chem);    
	        sc.close();
	        
	        ser.calculate(sm);
	        
	    }





	}
	 









